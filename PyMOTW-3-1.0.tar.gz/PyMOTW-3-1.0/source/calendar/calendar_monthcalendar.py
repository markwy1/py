#!/usr/bin/env python3
"""Show the dates in each week of a month.
"""
#end_pymotw_header
import calendar
import pprint

pprint.pprint(calendar.monthcalendar(2017, 7))
