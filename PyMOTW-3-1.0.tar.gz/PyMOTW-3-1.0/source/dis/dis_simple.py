#!/usr/bin/env python3
# encoding: utf-8

my_dict = {'a': 1}
