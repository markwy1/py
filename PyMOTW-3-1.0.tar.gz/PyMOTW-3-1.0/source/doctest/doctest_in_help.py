#!/usr/bin/env python3
# encoding: utf-8
#
# Copyright (c) 2010 Doug Hellmann.  All rights reserved.
#
"""Tests for this module are in the external help text.
"""
#end_pymotw_header
def my_function(a, b):
    """Returns a*b
    """
    return a * b
